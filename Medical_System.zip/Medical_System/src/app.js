const express = require('express');//It is a node js framework
const path = require('path');//It is used to detect the location of a file or folder
const bcrypt = require('bcrypt');//It allows your password to not be visible while it is being typed
const collection = require("./config");
const randomstring = require('randomstring');
const nodemailer = require('nodemailer');

const app = express();//It is an insstance of the class express, which is the framework being used

//Convert data into JSON format
app.use(express.json());

app.use(express.urlencoded({extended: false}));


//set ejs as the view engine
app.set('view engine', 'ejs');//Enables you render different html files as web pages with styles, decorations and animations.

//To set a static folder
app.use(express.static('public'));
app.use(express.static('JSscript'));

app.get('/',(req,res)=>{
    res.render("home");
});

app.get('/signup',(req,res)=>{
    res.render("signup");
});


app.get('/login',(req,res)=>{
    res.render("login");
});

app.get('/signup2',(req,res)=>{
    res.render("signup2");
});

app.get('/main', (req, res)=>{
    res.render("main")
});


app.post("/signup", async (req, res) => {
    try{         
        const verificationCode = randomstring.generate({length: 8, charset: 'alphanumeric'});
        
        const data = {
            name: req.body.username,
            password: req.body.password,
            role: req.body.role,
            verificationCode: verificationCode
        };

        //check if user exists
        const existingUser = await collection.findOne({name: data.name});
        if(existingUser){
            res.send("User already exists. Please use a different email");
        }else{
            //hash the password
            const saltRounds = 10;
            const hashPassword = await bcrypt.hash(data.password, saltRounds);
            data.password = hashPassword;

            const userData = await collection.insertMany(data);
            res.redirect('/login');
            console.log(verificationCode);
            console.log(data);
        }

        // const transporter = nodemailer.createTransport({
        //     host: 'smtp.gmail.com',
        //     port: 465,
        //     service: 'Gmail',
        //     secure: true,
        //     auth: {
        //         user: 'nwoguadanna85@gmail.com',
        //         pass: 'vanfleek0203'
        //     }
        // });

        // const mailOptions = {
        //     from: 'nwoguadanna85@gmail.com',
        //     to: req.body.username,
        //     subject: 'Your Hospital ID',
        //     text: `Your hospital ID is ${verificationCode}`
        // }

        // transporter.sendMail(mailOptions, (error, info) => {
        //     if(error) {
        //         console.log("Error:", error);
        //     }
        //     else{
        //         console.log("Hospital ID sent:", info.response);
        //         res.redirect('/login');
        //     }
        // });

    }catch(e){
        console.log(e);
    }
});

app.post('/login', async (req, res) => {
    try{
        const check = await collection.findOne({name: req.body.username});
        if(!check){
            res.send("User cannot be found");
        }
        const isPasswordMatch = await bcrypt.compare(req.body.password, check.password);
        if(isPasswordMatch){
            res.render('main');
        }
        else{
           res.send("Wrong details");
        }
    }catch(error){

    }
});



const port = 8080;
app.listen(port, () => {
    console.log(`Server is running on port: 127.0.0.1:${port}`);
});
//nodemon automatically reload your node application after you make a change