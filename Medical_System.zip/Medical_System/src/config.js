const mongoose = require('mongoose');
const connect = mongoose.connect("mongodb://localhost:27017/UHealth-authentication");

connect.then(()=>{
    console.log("Database conected successfully");
})
.catch(()=>{
    console.log("Database cannot be connected");
})

//create a schema
const logInSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    role: {
        type: String,
        required: true
    },
    hospitalID: {
        type: String,
        required: false
    }
});

//create a model
const collection = new mongoose.model("users", logInSchema);

module.exports = collection;