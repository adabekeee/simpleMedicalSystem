const countdownTime = 120;

const timerElement = document.getElementById('timer');

const countdownInterval = setInterval(updateTimer,1000);

function updateTimer() {
    const minutes = Math.floor(countdownTime/60);
    const seconds = countdownTime % 60;

    timerElement.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

    countdownTime--;

    if(countdownTime < 0){
        clearInterval(countdownInterval);
        timerElement.textContent = "Time is up";
    }
}